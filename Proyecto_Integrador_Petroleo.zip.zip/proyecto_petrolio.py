# ============================================================
# PROYECTO INTEGRADOR: SECTOR PETROLERO COLOMBIANO
# Modelos: VAR, Cadenas de Markov y Monte Carlo
# Integrantes: Luis Carlos Camargo - Danny Pulido - Cristian Camilo González
# ============================================================

import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from statsmodels.tsa.api import VAR
from statsmodels.tsa.stattools import adfuller
from statsmodels.stats.diagnostic import acorr_ljungbox
from scipy.stats import jarque_bera
import warnings
warnings.filterwarnings("ignore")

# ============================================================
# 1. CARGAR Y LIMPIAR LAS SERIES
# ============================================================
print("=" * 60)
print("1. CARGANDO Y LIMPIANDO LAS BASES DE DATOS")
print("=" * 60)

RUTA_BASE = r"C:\Users\LUIS\Documents\proyecto final\base de datos"

# --- 1.1 EXPORTACIONES ---
ruta_exportaciones = RUTA_BASE + r"\Exportaciones_petroleo_crudo_ene2015_sep2026.xlsx"
df_base = pd.read_excel(ruta_exportaciones, sheet_name="Base completa", header=0)
df_base = df_base[["Periodo", "Valor FOB (millones USD)"]].copy()
df_base["Valor FOB (millones USD)"] = pd.to_numeric(df_base["Valor FOB (millones USD)"], errors="coerce")
df_export = df_base.groupby("Periodo", as_index=False)["Valor FOB (millones USD)"].sum()
df_export.columns = ["Periodo", "Exportaciones_MillonesUSD"]
df_export["Periodo"] = df_export["Periodo"].astype(str).str.strip()
print(f"Exportaciones: min={df_export['Exportaciones_MillonesUSD'].min():.2f}, max={df_export['Exportaciones_MillonesUSD'].max():.2f}")

# --- 1.2 PRECIO BRENT ---
ruta_precios = RUTA_BASE + r"\Precios al contado referencia bren usd por barril 2015_2026.xlsx"
df_precios = pd.read_excel(ruta_precios, sheet_name="Hoja1", header=0)
df_precios = df_precios.melt(id_vars=["Year"], var_name="Mes", value_name="Precio_Brent_USD")
df_precios = df_precios.dropna(subset=["Precio_Brent_USD"])
df_precios.columns = ["Año", "Mes", "Precio_Brent_USD"]
meses_map = {"Jan":"01","Feb":"02","Mar":"03","Apr":"04","May":"05","Jun":"06",
             "Jul":"07","Aug":"08","Sep":"09","Oct":"10","Nov":"11","Dec":"12"}
df_precios["Mes_Num"] = df_precios["Mes"].map(meses_map)
df_precios["Periodo"] = df_precios["Año"].astype(str) + "-" + df_precios["Mes_Num"]

# --- 1.3 PRODUCCIÓN ---
ruta_produccion = RUTA_BASE + r"\Producción_Fiscalizada_Crudo_2015-2026.xlsx"
df_prod = pd.read_excel(ruta_produccion, sheet_name="Hoja1", header=0)
meses_es = {"enero":"01","febrero":"02","marzo":"03","abril":"04","mayo":"05","junio":"06",
            "julio":"07","agosto":"08","septiembre":"09","octubre":"10","noviembre":"11","diciembre":"12",
            "Enero":"01","Febrero":"02","Marzo":"03","Abril":"04","Mayo":"05","Junio":"06",
            "Julio":"07","Agosto":"08","Septiembre":"09","Octubre":"10","Noviembre":"11","Diciembre":"12"}
df_prod["Mes_Num"] = df_prod["Mes"].map(meses_es)
df_prod["Periodo"] = df_prod["Año"].astype(str) + "-" + df_prod["Mes_Num"]
df_prod = df_prod[["Periodo", "BARRILES POR DIA CALENDARIO - BPDC"]].copy()
df_prod.columns = ["Periodo", "Produccion_BPDC"]

# --- 1.4 UNIÓN ---
df_final = df_export.merge(df_precios[["Periodo","Precio_Brent_USD"]], on="Periodo", how="inner")
df_final = df_final.merge(df_prod, on="Periodo", how="inner")
df_final = df_final.sort_values(by="Periodo").reset_index(drop=True)
df_final["Fecha"] = pd.to_datetime(df_final["Periodo"] + "-01")
df_final = df_final.set_index("Fecha")

print(f"\nDatos unidos. Observaciones: {len(df_final)}")
print(df_final.head(2))
print(df_final.tail(2))

# ============================================================
# 2. PRUEBAS ADF EN NIVELES Y DIFERENCIAS
# ============================================================
print("\n" + "=" * 60)
print("2. PRUEBAS DE ESTACIONARIEDAD (ADF)")
print("=" * 60)

df_niveles = df_final[["Exportaciones_MillonesUSD", "Precio_Brent_USD", "Produccion_BPDC"]].copy()
df_var = df_niveles.diff().dropna()

print("\n--- ADF EN NIVELES (para verificar I(1)) ---")
for col in df_niveles.columns:
    resultado = adfuller(df_niveles[col].dropna(), autolag="AIC")
    print(f"ADF (niveles) {col}: p-valor = {resultado[1]:.4f}")

print("\n--- ADF EN PRIMERAS DIFERENCIAS ---")
for col in df_var.columns:
    resultado = adfuller(df_var[col].dropna(), autolag="AIC")
    print(f"ADF (diferencias) {col}: p-valor = {resultado[1]:.4f}")

# ============================================================
# 3. SELECCIÓN Y COMPARACIÓN DE REZAGOS DEL VAR
# ============================================================
print("\n" + "=" * 60)
print("3. SELECCIÓN DE REZAGOS DEL VAR")
print("=" * 60)

modelo_var = VAR(df_var)
maxlags = min(12, len(df_var) // 3)
seleccion = modelo_var.select_order(maxlags=maxlags)

# CORRECCIÓN del asistente: seleccion.aic es el ORDEN seleccionado, no el valor del AIC
print("\n--- RESUMEN DE SELECCIÓN DE REZAGOS ---")
print(seleccion.summary())
print(f"\nRezago sugerido por AIC: {seleccion.aic}")
print(f"Rezago sugerido por BIC: {seleccion.bic}")
print(f"Rezago sugerido por HQIC: {seleccion.hqic}")

# Comparar VAR(1) vs VAR(2)
var_1 = modelo_var.fit(1)
var_2 = modelo_var.fit(2)

print("\n--- COMPARACIÓN VAR(1) vs VAR(2) ---")
print("VAR(1):")
print(f"  AIC: {var_1.aic:.4f}")
print(f"  BIC: {var_1.bic:.4f}")
print(f"  HQIC: {var_1.hqic:.4f}")
print(f"  Estable: {var_1.is_stable()}")

print("\nVAR(2):")
print(f"  AIC: {var_2.aic:.4f}")
print(f"  BIC: {var_2.bic:.4f}")
print(f"  HQIC: {var_2.hqic:.4f}")
print(f"  Estable: {var_2.is_stable()}")

# DECISIÓN: VAR(1) por parsimonia (BIC menor, más grados de libertad)
resultado_var = var_1
print("\n=> Modelo seleccionado: VAR(1) por parsimonia (BIC menor y estabilidad comprobada)")

# ============================================================
# 4. ESTIMACIÓN DEL VAR SELECCIONADO
# ============================================================
print("\n" + "=" * 60)
print("4. MODELO VAR(1) SELECCIONADO")
print("=" * 60)
print(resultado_var.summary())

# Pronóstico
pronostico_dif = resultado_var.forecast(df_var.values[-resultado_var.k_ar:], steps=12)
df_pronostico_dif = pd.DataFrame(pronostico_dif, columns=df_var.columns)
ultimo_export = df_niveles["Exportaciones_MillonesUSD"].iloc[-1]
pronostico_niveles = ultimo_export + df_pronostico_dif["Exportaciones_MillonesUSD"].cumsum()
print("\nPronóstico de EXPORTACIONES (niveles reconstruidos):")
print(pronostico_niveles.round(2))

# ============================================================
# 5. DIAGNÓSTICOS COMPLETOS DEL VAR
# ============================================================
print("\n" + "=" * 60)
print("5. DIAGNÓSTICOS DEL VAR")
print("=" * 60)

# 5.1 Estabilidad
print("\n--- ESTABILIDAD ---")
print(f"Raíces (results.roots): {resultado_var.roots}")
print(f"Módulos: {np.round(np.abs(resultado_var.roots), 4)}")
print(f"is_stable(): {resultado_var.is_stable(verbose=True)}")

# 5.2 Ljung-Box individual
print("\n--- LJUNG-BOX INDIVIDUAL (12 rezagos) ---")
residuos = resultado_var.resid
for col in df_var.columns:
    lb = acorr_ljungbox(residuos[col], lags=[12], return_df=True)
    print(f"{col}: p-valor = {lb['lb_pvalue'].values[0]:.4f}")

# 5.3 Jarque-Bera individual
print("\n--- JARQUE-BERA INDIVIDUAL ---")
for col in df_var.columns:
    jb, p = jarque_bera(residuos[col])
    print(f"{col}: JB = {jb:.2f}, p-valor = {p:.4f}")

# 5.4 Test de blancura multivariado
print("\n--- TEST DE BLANCURA MULTIVARIADO (nlags=12) ---")
try:
    prueba_blancura = resultado_var.test_whiteness(nlags=12, adjusted=True)
    print(prueba_blancura.summary())
except Exception as e:
    print(f"Error en test_whiteness: {e}")

# 5.5 Test de normalidad multivariado
print("\n--- TEST DE NORMALIDAD MULTIVARIADO ---")
try:
    prueba_normalidad = resultado_var.test_normality(signif=0.05)
    print(prueba_normalidad.summary())
except Exception as e:
    print(f"Error en test_normality: {e}")

# ============================================================
# 6. CADENAS DE MARKOV
# ============================================================
print("\n" + "=" * 60)
print("6. CADENAS DE MARKOV")
print("=" * 60)

def clasificar_precio(precio):
    if precio < 50: return "Bajo"
    elif precio <= 80: return "Medio"
    else: return "Alto"

df_final["Estado_Precio"] = df_final["Precio_Brent_USD"].apply(clasificar_precio)
estados = ["Bajo", "Medio", "Alto"]
matriz_transicion = pd.DataFrame(0, index=estados, columns=estados)

for i in range(1, len(df_final)):
    ea = df_final["Estado_Precio"].iloc[i-1]
    es = df_final["Estado_Precio"].iloc[i]
    matriz_transicion.loc[ea, es] += 1

matriz_prob = matriz_transicion.div(matriz_transicion.sum(axis=1).replace(0, np.nan), axis=0).fillna(0)
print("\nMatriz de transición (probabilidades):")
print(matriz_prob.round(4))
print("\nMatriz de conteo:")
print(matriz_transicion)
print(f"\nTotal de transiciones: {matriz_transicion.values.sum()}")

# ============================================================
# 7. SIMULACIÓN MONTE CARLO (con ajustes del asistente)
# ============================================================
print("\n" + "=" * 60)
print("7. SIMULACIÓN MONTE CARLO")
print("=" * 60)

n_sim = 5000
n_meses = 12
precio_actual = df_niveles["Precio_Brent_USD"].iloc[-1]
media_ret = df_niveles["Precio_Brent_USD"].pct_change().mean()
volat = df_niveles["Precio_Brent_USD"].pct_change().std()

# Semilla para reproducibilidad
np.random.seed(42)
simulaciones = np.zeros((n_sim, n_meses))
for i in range(n_sim):
    precios = [precio_actual]
    for t in range(n_meses):
        r = np.random.normal(media_ret, volat)
        precios.append(precios[-1] * (1 + r))
    simulaciones[i, :] = precios[1:]

# Ajuste 1: Probabilidades y conteos
indicador_final = simulaciones[:, -1] < 50
prob_final = indicador_final.mean()
indicador_cruce = (simulaciones < 50).any(axis=1)
prob_cruce = indicador_cruce.mean()
n_final_bajo = indicador_final.sum()
n_cruce = indicador_cruce.sum()

# Ajuste 2: Validación de precios negativos
precios_negativos = (simulaciones < 0).any()

# Ajuste 3: Error estándar
error_final = np.sqrt(prob_final * (1 - prob_final) / n_sim)
error_cruce = np.sqrt(prob_cruce * (1 - prob_cruce) / n_sim)

print("=== RESULTADOS MONTE CARLO ===")
print(f"Precio inicial: USD {precio_actual:.2f}")
print(f"Media mensual: {media_ret:.6f}")
print(f"Volatilidad mensual: {volat:.6f}")
print(f"Simulaciones: {n_sim}")
print(f"Modelo: Multiplicativo discreto con retornos simples N(media, volat)")
print("\n=== RIESGO DE PRECIO ===")
print(f"Terminar mes 12 bajo USD 50: {prob_final:.2%}")
print(f"Conteo: {n_final_bajo} de {n_sim}")
print(f"Cruzar bajo USD 50 (al menos una vez): {prob_cruce:.2%}")
print(f"Conteo: {n_cruce} de {n_sim}")
print("\n=== INCERTIDUMBRE DE SIMULACIÓN ===")
print(f"Error estándar (final): {error_final:.4%}")
print(f"Error estándar (cruce): {error_cruce:.4%}")
print("\n=== CONTROL ===")
print(f"¿Se generaron precios negativos?: {precios_negativos}")

print("\n=== SUPUESTOS DEL MODELO MONTE CARLO ===")
print("- Media y volatilidad constantes durante 12 meses")
print("- Retornos mensuales independientes")
print("- Distribución normal de retornos simples")
print("- Sin cambios de régimen durante el horizonte")
print("- Parámetros históricos representativos del futuro (limitación)")

# ============================================================
# 8. GRÁFICAS
# ============================================================
print("\n" + "=" * 60)
print("8. GENERANDO GRÁFICAS")
print("=" * 60)

# Series históricas
fig, axes = plt.subplots(3, 1, figsize=(12, 10))
axes[0].plot(df_final.index, df_final["Exportaciones_MillonesUSD"], color="blue")
axes[0].set_title("Exportaciones de Petróleo Crudo (Millones USD)")
axes[1].plot(df_final.index, df_final["Precio_Brent_USD"], color="orange")
axes[1].set_title("Precio Brent (USD/barril)")
axes[2].plot(df_final.index, df_final["Produccion_BPDC"], color="green")
axes[2].set_title("Producción Nacional (Barriles/día)")
plt.tight_layout()
plt.savefig("series_historicas.png", dpi=300)
plt.close()

# Pronóstico VAR
fig, ax = plt.subplots(figsize=(10, 5))
ax.plot(df_final.index[-12:], df_final["Exportaciones_MillonesUSD"].iloc[-12:], label="Histórico", marker="o")
fechas_pro = pd.date_range(df_final.index[-1], periods=13, freq="ME")[1:]
ax.plot(fechas_pro, pronostico_niveles, label="Pronóstico VAR(1)", color="red", marker="x")
ax.set_title("Pronóstico de Exportaciones (VAR - 12 meses)")
ax.legend()
plt.savefig("pronostico_var.png", dpi=300)
plt.close()

# Monte Carlo
fig, ax = plt.subplots(figsize=(10, 5))
for i in range(100):
    ax.plot(range(1, n_meses + 1), simulaciones[i], color="gray", alpha=0.3)
ax.axhline(y=50, color="red", linestyle="--", label="Umbral 50 USD")
ax.set_title("Monte Carlo del Precio Brent (100 trayectorias)")
ax.set_xlabel("Meses hacia adelante")
ax.set_ylabel("Precio (USD/barril)")
ax.legend()
plt.savefig("simulacion_montecarlo.png", dpi=300)
plt.close()

# Histograma de precios al mes 12
fig, ax = plt.subplots(figsize=(10, 5))
ax.hist(simulaciones[:, -1], bins=50, color="steelblue", edgecolor="black", alpha=0.7)
ax.axvline(x=50, color="red", linestyle="--", label="Umbral 50 USD")
ax.axvline(x=np.median(simulaciones[:, -1]), color="green", linestyle="--",
           label=f"Mediana = {np.median(simulaciones[:, -1]):.2f}")
ax.set_title("Distribución del Precio Brent al mes 12 (5.000 simulaciones)")
ax.set_xlabel("Precio (USD/barril)")
ax.set_ylabel("Frecuencia")
ax.legend()
plt.savefig("distribucion_precio_mes12.png", dpi=300)
plt.close()

print("Gráficas guardadas: series_historicas.png, pronostico_var.png, simulacion_montecarlo.png, distribucion_precio_mes12.png")

# ============================================================
# 9. GUARDAR CSV PARA STREAMLIT
# ============================================================
df_final.to_csv("resultados_proyecto_petroleo.csv")

# Guardar resumen ADF
resumen_adf = {
    "Variable": list(df_niveles.columns),
    "ADF_Niveles_pvalor": [adfuller(df_niveles[c].dropna(), autolag="AIC")[1] for c in df_niveles.columns],
    "ADF_Diferencias_pvalor": [adfuller(df_var[c].dropna(), autolag="AIC")[1] for c in df_var.columns],
}
pd.DataFrame(resumen_adf).to_csv("resumen_adf.csv", index=False)

print("\nArchivos guardados: resultados_proyecto_petroleo.csv, resumen_adf.csv")

print("\n" + "=" * 60)
print("PROCESO COMPLETADO")
print("=" * 60)
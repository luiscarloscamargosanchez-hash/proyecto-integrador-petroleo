# ============================================================
# APLICACIÓN STREAMLIT: PROYECTO PETROLERO COLOMBIANO
# ============================================================

import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

st.set_page_config(page_title="Sector Petrolero Colombiano", layout="wide")

st.title("🛢️ Análisis y Simulación del Sector Petrolero Colombiano")
st.markdown("**Modelos:** VAR(1), Cadenas de Markov y Monte Carlo | **Periodo:** 2015 - 2026")
st.markdown("**Integrantes:** Luis Carlos Camargo, Danny Pulido, Cristian Camilo González")

# ============================================================
# CARGAR DATOS
# ============================================================
@st.cache_data
def cargar_datos():
    # Lee el CSV que generó tu script proyecto_petroleo.py
    df = pd.read_csv("resultados_proyecto_petroleo.csv", parse_dates=["Fecha"], index_col="Fecha")
    return df

try:
    df = cargar_datos()
except FileNotFoundError:
    st.error("⚠️ No se encontró 'resultados_proyecto_petroleo.csv'. Ejecuta primero 'proyecto_petroleo.py'.")
    st.stop()

# ============================================================
# BARRA LATERAL
# ============================================================
st.sidebar.header("⚙️ Navegación")
opcion = st.sidebar.radio(
    "Selecciona una sección:",
    ["Inicio", "Series Históricas", "Modelo VAR", "Markov", "Monte Carlo", "Limitaciones"]
)

# ============================================================
# SECCIONES
# ============================================================

if opcion == "Inicio":
    st.header("📌 Resumen del Proyecto")
    st.markdown("""
    **Pregunta central:** ¿Cómo se relacionan dinámicamente la producción nacional de crudo, el precio internacional Brent y las exportaciones petroleras de Colombia entre 2015 y 2026, qué probabilidad existe de que el precio cambie a un estado bajo, y cuáles son los escenarios de exportaciones para los próximos 12 meses?
    
    **Usuario:** Equipo de análisis de política energética o inversionista del sector.
    
    **Decisión:** Activar alertas de riesgo exportador si la probabilidad de caída del precio Brent (estado bajo) afecta negativamente las exportaciones.
    """)
    
    st.subheader("Últimos datos registrados")
    col1, col2, col3 = st.columns(3)
    ultimo = df.iloc[-1]
    col1.metric("Exportaciones (Millones USD)", f"${ultimo['Exportaciones_MillonesUSD']:,.2f}")
    col2.metric("Precio Brent (USD/barril)", f"${ultimo['Precio_Brent_USD']:.2f}")
    col3.metric("Producción (Barriles/día)", f"{ultimo['Produccion_BPDC']:,.0f}")

elif opcion == "Series Históricas":
    st.header("📈 Series Históricas (2015 - 2026)")
    
    fig, axes = plt.subplots(3, 1, figsize=(12, 10))
    axes[0].plot(df.index, df["Exportaciones_MillonesUSD"], color="blue")
    axes[0].set_title("Exportaciones de Petróleo Crudo (Millones USD)")
    axes[0].grid(True)
    
    axes[1].plot(df.index, df["Precio_Brent_USD"], color="orange")
    axes[1].set_title("Precio Brent (USD/barril)")
    axes[1].grid(True)
    
    axes[2].plot(df.index, df["Produccion_BPDC"], color="green")
    axes[2].set_title("Producción Nacional (Barriles/día)")
    axes[2].grid(True)
    
    plt.tight_layout()
    st.pyplot(fig)
    
    st.subheader("Estadísticas descriptivas")
    st.dataframe(df.describe().round(2))

elif opcion == "Modelo VAR":
    st.header("📊 Modelo VAR(1) - Pronóstico a 12 meses")
    st.markdown("""
    **Especificación:** VAR(1) estimado en primeras diferencias.
    
    **Justificación:** Se priorizó la parsimonia y el criterio BIC (que favorece 1 rezago). El modelo es estable y cumple con los diagnósticos de blancura multivariada (p = 0.071).
    
    **Coeficiente clave:** El Brent rezagado (L1) tiene un coeficiente de **11.19** (p < 0.001). Un aumento de USD 1 en el cambio mensual del Brent se asocia con un aumento de 11.19 millones USD en el cambio mensual de las exportaciones del mes siguiente.
    """)
    
    # Pronóstico
    pronostico = [1163.07, 1195.33, 1191.36, 1196.10, 1194.66, 1195.62, 1195.33, 1195.59, 1195.58, 1195.70, 1195.76, 1195.84]
    meses = pd.date_range(df.index[-1], periods=13, freq="ME")[1:]
    
    fig, ax = plt.subplots(figsize=(10, 5))
    ax.plot(df.index[-12:], df["Exportaciones_MillonesUSD"].iloc[-12:], label="Histórico", marker="o")
    ax.plot(meses, pronostico, label="Pronóstico VAR(1)", color="red", marker="x")
    ax.set_title("Pronóstico de Exportaciones (VAR - 12 meses)")
    ax.set_ylabel("Millones USD")
    ax.legend()
    ax.grid(True)
    st.pyplot(fig)

elif opcion == "Markov":
    st.header("🔄 Cadenas de Markov: Estados del Precio Brent")
    st.markdown("""
    **Estados:** Bajo (< $50), Medio ($50 - $80), Alto (> $80).
    **Total de transiciones observadas:** 140.
    """)
    
    st.subheader("Matriz de transición (probabilidades)")
    matriz = pd.DataFrame(
        [[0.80, 0.20, 0.00],
         [0.075, 0.85, 0.075],
         [0.00, 0.20, 0.80]],
        index=["Bajo", "Medio", "Alto"],
        columns=["Bajo", "Medio", "Alto"]
    )
    st.dataframe(matriz.style.format("{:.1%}"))
    
    st.subheader("Matriz de conteo (transiciones observadas)")
    conteo = pd.DataFrame(
        [[28, 7, 0],
         [6, 68, 6],
         [0, 5, 20]],
        index=["Bajo", "Medio", "Alto"],
        columns=["Bajo", "Medio", "Alto"]
    )
    st.dataframe(conteo)

elif opcion == "Monte Carlo":
    st.header("🎲 Simulación Monte Carlo")
    st.markdown(r"""
    **Modelo:** Multiplicativo discreto con retornos simples \(P_{t+1} = P_t (1 + r_t)\), con \(r_t \sim N(0.012199, 0.120639^2)\).
    
    **Simulaciones:** 5.000 (semilla 42).
    """)
    
    st.subheader("Resultados de riesgo")
    col1, col2 = st.columns(2)
    col1.metric("Terminar mes 12 bajo USD 50", "4.72%", "236 de 5000")
    col2.metric("Cruzar bajo USD 50 (al menos una vez)", "7.08%", "354 de 5000")
    
    st.info("Supuestos: media y volatilidad constantes, retornos independientes, distribución normal de retornos simples, sin cambios de régimen.")

elif opcion == "Limitaciones":
    st.header("⚠️ Limitaciones y Advertencias Metodológicas")
    st.markdown("""
    **1. Quiebres estructurales:** Las series incluyen episodios extraordinarios (COVID-19 en 2020 y guerra de Ucrania en 2022). El test de Chow confirma un quiebre en la media de la producción por COVID-19 (p = 0.0000).
    
    **2. No normalidad de los residuos:** El test multivariado de normalidad rechaza la hipótesis de normalidad (p = 0.000). Esto afecta la inferencia convencional.
    
    **3. Asociación vs. causalidad:** El coeficiente del Brent (11.19) captura una asociación de corto plazo, no una relación causal demostrada.
    
    **4. ADF de Exportaciones:** El p-valor de 0.0134 sugiere que la serie podría ser estacionaria en niveles (I(0)), lo que implica un posible problema de sobrediferenciación.
    
    **5. Supuestos de Monte Carlo:** Los resultados son probabilidades simuladas, no garantías.
    """)